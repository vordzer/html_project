$(document).ready(function(){
            $("a.gallery").fancybox();
			jQuery('#slider1').tinycarousel();
			jQuery('#slider2').tinycarousel();
			jQuery('#slider3').tinycarousel();
			jQuery('#slider4').tinycarousel();
			jQuery('#slider5').tinycarousel();
			jQuery('#slider0').tinycarousel();
            jQuery('.hide_ex').hide();
    		jQuery('.popup_all').click(function () {
			jQuery('#pop_up_shell_all').fadeIn(500);
			jQuery('#pop_up_all').fadeIn(500);
			return false;
		});		
    		jQuery('.popup_call').click(function () {
			jQuery('#pop_up_shell_call').fadeIn(500);
			jQuery('#pop_up_call').fadeIn(500);
			return false;
		});		
    		jQuery('.popup_raschet').click(function () {
			jQuery('#pop_up_shell_raschet').fadeIn(500);
			jQuery('#pop_up_raschet').fadeIn(500);
			return false;
		});		
    		jQuery('.popup_podr').click(function () {
			jQuery('#pop_up_shell_podr').fadeIn(500);
			jQuery('#pop_up_podr').fadeIn(500);
			return false;
		});		
    		jQuery('.pop_up').click(function () {
			return false;
		});		
jQuery('.pop_up_shell').hide();
jQuery('#thanks_shell').hide();
		jQuery('.popular_most_gallery_item img').click(function () {
		    jQuery(this).parent().parent().parent().parent().parent().parent().parent().find('.popular_most_image img').attr("src", jQuery(this).attr("src"));
            return false;
		});		
    		jQuery('.show_ex').click(function () {
    		  jQuery(this).parent().parent().parent().find('.hide_ex').show();
			return false;
		});			
    		jQuery('.close').click(function () {
			jQuery('.pop_up_shell').fadeOut(500);
			jQuery('.pop_up').fadeOut(500);
			return false;
		});				
    		jQuery('html').click(function () {
			jQuery('.pop_up_shell').fadeOut(500);
			jQuery('.pop_up').fadeOut(500);
			jQuery('.thanks_shell').fadeOut(500);
			jQuery('.thanks').fadeOut(500);
		});			
        jQuery('.pop_up_shell').click(function () {
			jQuery('.pop_up_shell').fadeOut(500);
			jQuery('.pop_up').fadeOut(500);
		});
$('.scroll').bind("click", function(e){
      var anchor = $(this);
      $('html, body').stop().animate({
         scrollTop: $(anchor.attr('href')).offset().top
      }, 2000);
      e.preventDefault();
   return false;
   });


    $(function () {

	/***********************************************************************************/
	jQuery('#p_submit_all, #p_submit_call, #p_submit_podr, #p_submit_raschet, #m_submit, #i_submit, #c_submit').click(function () {
		//Get the data from all the fields
		var name_top = jQuery('body').find('input[name=name_top]');
		var name_ind = jQuery('body').find('input[name=name_ind]');
		var name_call = jQuery('body').find('input[name=name_call]');
		var phone_top = jQuery('body').find('input[name=phone_top]');
		var phone_ind = jQuery('body').find('input[name=phone_ind]');
		var phone_calli = jQuery('body').find('input[name=phone_calli]');
		var phone_all = jQuery('body').find('input[name=phone_all]');
		var phone_call = jQuery('body').find('input[name=phone_call]');
		var phone_podr = jQuery('body').find('input[name=phone_podr]');
		var phone_raschet = jQuery('body').find('input[name=phone_raschet]');
		var type= jQuery('body').find('.checked').find('input[name=type]');
		var material= jQuery('body').find('.checked').find('input[name=material]');
		var max_area= jQuery('body').find('input[name=max_area]');
		var min_area= jQuery('body').find('input[name=min_area]');
		var max_cost= jQuery('body').find('input[name=max_cost]');
		var path= jQuery('body').find('input[name=path]');
		var floors= jQuery('body').find('select[name=floors]');
		var extension= jQuery('body').find('select[name=extension]');

		//Simple validation to make sure user entered something
		//If error found, add hightlight class to the text field
		
		
		//organize the data properly
		var data = '&name=' + name_top.val() + name_ind.val() + name_call.val() + '&phone=' + phone_top.val() + phone_ind.val() + phone_calli.val() + phone_all.val() + phone_raschet.val() + phone_podr.val() + phone_call.val() + '&max_area=' + max_area.val() + '&floors=' + floors.val() + '&extension=' + extension.val() + '&min_area=' + min_area.val() + '&max_cost=' + max_cost.val() + '&type=' + 
		type.val() +'&material=' + material.val(); //+ '&comment='  + encodeURIComponent(comment.val());
		
		//disabled all the text fields
		//jQuery('.text').attr('disabled','true');
		
		//show the loading sign
		//jQuery('.loading').show();
		//start the ajax
		jQuery.ajax({
			//this is the php file that processes the data and send mail
			url: path.val(),
			
			//GET method is used
			type: "POST",

			//pass the data			
			data: data,
			
			//Do not cache the page
			cache: false,
			
            error: function(html){alert('Ваше сообщение неотправленно');},
			//success
			success: function (html) {				
				//if process.php returned 1/true (send mail success)
				if (html==1) {						
					//hide the form
                    jQuery('.pop_up_shell').fadeOut(500);
                    jQuery('.form_cell input[type=text').val("");
                    jQuery('#thanks_shell').fadeIn(500);
                    setTimeout('jQuery("#thanks_shell").hide();',3000);
					jQuery('#contactForm input[type=text]').val("").css('border','1px solid #E5E5E5');
					jQuery('.contactForm input[type=text]').val("").css('border','1px solid #E5E5E5');
					jQuery('#contactForm1 input[type=text]').val("").css('border','1px solid #E5E5E5');
					jQuery('#contactForm2 input[type=text]').val("").css('border','1px solid #E5E5E5');				
					
					//show the success message
					
					
					
				//if process.php returned 0/false (send mail failed)
				} else {
                    jQuery('.pop_up_shell').fadeOut(500);
                    jQuery('input[type=text').val("");
                    jQuery('#thanks_shell').fadeIn(500);
                    setTimeout('jQuery("#thanks_shell").fadeOut(500);',3000);
                }				
			}		
		});
		
		//cancel the submit button default behaviours
		return false;
	});	
	/***********************************************************************************/

	
	jQuery('input[data-placeholder], textarea[data-placeholder]').each(function() {
		var placeholder = jQuery(this).attr('data-placeholder');
		if (((jQuery(this).val() !== undefined) && (jQuery(this).val().length > 0)) && (jQuery(this).val() != placeholder)) {
			jQuery(this).removeClass('placeholder');
		} else {
			jQuery(this).val(placeholder);
			jQuery(this).addClass('placeholder');
		}
		jQuery(this).focusin(function() {
			jQuery(this).removeClass('placeholder');
			if ((jQuery(this).val() === undefined) || (jQuery(this).val() == placeholder)) {
				jQuery(this).val('');
			}
		});
		jQuery(this).focusout(function() {
			if ((jQuery(this).val() === undefined) || (jQuery(this).val() == '') || (jQuery(this).val() == placeholder)) {
				jQuery(this).val(placeholder);
				jQuery(this).addClass('placeholder');		
			}
		});		
	});
	
	jQuery('form').submit(function() {
		jQuery(this).find('input[data-placeholder], textarea[data-placeholder]').each(function() {
			var placeholder = jQuery(this).attr('data-placeholder');
			jQuery(this).removeClass('placeholder');
			if ((jQuery(this).val() === undefined) || (jQuery(this).val() == placeholder)) {
				jQuery(this).val('');
			}	
		});
	});
    
	});
});