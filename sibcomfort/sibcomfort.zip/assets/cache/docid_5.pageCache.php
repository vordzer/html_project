<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:1:"5";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:14:"Проекты";s:9:"longtitle";s:14:"Проекты";s:11:"description";s:0:"";s:5:"alias";s:11:"our_project";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"1";s:9:"introtext";s:0:"";s:7:"content";s:0:"";s:8:"richtext";s:1:"1";s:8:"template";s:1:"9";s:9:"menuindex";s:1:"3";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407524483";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407561963";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407524483";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="popular" class="section">
            <a id="our_project" class="anchor"></a>
			<div id="popular_t" class="section">
				<div id="popular_column" class="column">
					<div id="popular_title">
						<h2>Проекты</h2>
					</div>
					<div id="popular_items">
						<div id="popular_list">

							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd1/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(0)">Подробнее</a>
								</div>
							</div>							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd2/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(1)">Подробнее</a>
								</div>
							</div>							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd3/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(2)">Подробнее</a>
								</div>
							</div>
							<div class="popular_item last">
								<a href="#" class="popup_all">Смотреть все проекты</a>
							</div>
							<div class="clear"></div>
							<div id="popular_most0" class="popular_most" style="display:none;">
								<div id="popular_most_arrow0" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd1/img_popular_most.jpg" alt="">
										</div>
										<div id="slider0" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd1/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd1/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd1/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd1/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>проект Д1</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div id="popular_most1" class="popular_most" style="display:none;">
								<div id="popular_most_arrow1" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd2/img_popular_most.jpg" alt="">
										</div>
										<div id="slider1" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd2/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd2/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd2/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd2/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>Проект Д2</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div id="popular_most2" class="popular_most" style="display:none;">
								<div id="popular_most_arrow2" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd3/img_popular_most.jpg" alt="">
										</div>
										<div id="slider2" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd3/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd3/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd3/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd3/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>Проект Д3</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
<div class="clear"></div>
							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd4/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(3)">Подробнее</a>
								</div>
							</div>							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd5/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(4)">Подробнее</a>
								</div>
							</div>							<div class="popular_item">
								<div class="popular_item_image">
									<img src="assets/images/proektd6/img_popular_most.jpg" alt="Дом 6x6">
								</div>
								<div class="popular_item_title">
									<span>Дом 6х6</span>
								</div>
								<div class="popular_item_price">
									<span>от 450 000 руб</span>
								</div>
								<div class="popular_item_more">
									<a class="button" onclick="popular(5)">Подробнее</a>
								</div>
							</div>
							<div class="popular_item last">
								<a href="#" class="popup_all">Смотреть все проекты</a>
							</div>
							<div class="clear"></div>
							<div id="popular_most3" class="popular_most" style="display:none;">
								<div id="popular_most_arrow3" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd4/img_popular_most.jpg" alt="">
										</div>
										<div id="slider3" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd4/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd4/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd4/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd4/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>Проект Д4</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div id="popular_most4" class="popular_most" style="display:none;">
								<div id="popular_most_arrow4" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd5/img_popular_most.jpg" alt="">
										</div>
										<div id="slider4" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd5/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd5/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd5/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd5/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>Проект Д5</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div id="popular_most5" class="popular_most" style="display:none;">
								<div id="popular_most_arrow5" class="popular_most_arrow"></div>
								<div class="popular_most_container">
									<div class="popular_most_images">
										<div class="popular_most_image">
											<img src="assets/images/proektd6/img_popular_most.jpg" alt="">
										</div>
										<div id="slider5" class="popular_most_gallery slider">
		<a class="buttons prev" href="#">&#60;</a>
		<div class="viewport">
            <ul class="overview">
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd6/img_popular_most.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd6/img_popular_most_gallery2.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd6/img_popular_most_gallery1.jpg">
											</div></li>
											<li><div class="popular_most_gallery_item">
												<img src="/assets/images/proektd6/img_popular_most_gallery.jpg">
											</div></li>
            </ul>
		</div>
		<a class="buttons next" href="#">&#62;</a>
										</div>
									</div>
									<div class="popular_most_decription">
										<div class="popular_most_title">
											<span>Проект Д6</span>
										</div>
										<div class="popular_most_info">							
											<ul>
												<li><span>Размер дома: 6х6</span></li>
												<li><span>Общая площадь дома: 44 кв.м.</span></li>
												<li><span>Материал стен: Брус</span></li>
												<li><span>Фундамент: свайно-винтовой или ленточный</span></li>
												<li><span>Количество этажей: 2</span></li>
												<li><span>Высота этажей:<br>1-й этаж — 2,4 м; 2-й этаж — 2,3 м</span></li>
												<li><span>Количество жилых комнат: 2</span></li>
											</ul>
										</div>
										<div class="popular_most_price">
											<span>от 450 000 руб</span>
										</div>
										<div class="popular_most_buttons">
											<a href="#" class="button popup_raschet">Заказать расчёт</a>
											<a href="#" class="button popup_podr button_grey">Подробнее</a>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>
		</div>