<?php die('Unauthorized access.'); ?>a:39:{s:2:"id";s:1:"8";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:6:"header";s:9:"longtitle";s:0:"";s:11:"description";s:0:"";s:5:"alias";s:0:"";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:278:"<p><img src="assets/templates/modxhost/img/ico_phone.png" alt="Заказать звонок" /> <span class="call_code">+7 (800)</span> <span class="call_number">112-43-67</span> <a href="#" id="header_order_call" class="button popup_call">Заказать звонок</a></p>";s:8:"richtext";s:1:"1";s:8:"template";s:1:"5";s:9:"menuindex";s:1:"6";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407562026";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1408036257";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407562026";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"1";s:4:"logo";a:5:{i:0;s:4:"logo";i:1;s:25:"assets/images/bg_logo.png";i:2;s:0:"";i:3;s:0:"";i:4;s:5:"image";}s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="header" class="section">
			<div id="header_b" class="section">
				<div id="header_column" class="column">
					<div id="header_logo">
						<a href="#"><img src="assets/images/bg_logo.png" alt="SibComfort"></a>
					</div>
					<div id="header_call">
						<p><img src="assets/templates/modxhost/img/ico_phone.png" alt="Заказать звонок" /> <span class="call_code">+7 (800)</span> <span class="call_number">112-43-67</span> <a href="#" id="header_order_call" class="button popup_call">Заказать звонок</a></p>
					</div>
				</div>
			</div>
		</div>