<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:1:"1";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:14:"Главная";s:9:"longtitle";s:14:"Главная";s:11:"description";s:0:"";s:5:"alias";s:7:"wrapper";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:401:"<h3>Install Successful!</h3>
<p>You have successfully installed MODX.</p>
<h3>Getting Help</h3>
<p>The <a href="http://forums.modx.com/" target="_blank">MODX Community</a> provides a great starting point to learn all things MODX, or you can also <a href="http://modxcms.com/learn/it.html">see some great learning resources</a> (books, tutorials, blogs and screencasts).</p>
<p>Welcome to MODX!</p>";s:8:"richtext";s:1:"1";s:8:"template";s:1:"3";s:9:"menuindex";s:1:"0";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1130304721";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407561007";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1130304721";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:14:"Главная";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__--><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<base href="http://xn--90anhijbobqr.xn--p1ai/">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Job</title>
<link href="/assets/templates/modxhost/css/jquery.formstyler.css" rel="stylesheet" />
<link href="/assets/templates/modxhost/css/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="/assets/templates/modxhost/source/jquery.fancybox.css?v=2.1.5" media="screen" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="/assets/templates/modxhost/js/jquery.formstyler.js"></script>
<script type="text/javascript" src="/assets/templates/modxhost/js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="/assets/templates/modxhost/js/jquery.tinycarousel.js"></script>
<script type="text/javascript" src="/assets/templates/modxhost/source/jquery.fancybox.js?v=2.1.5"></script>
<script type="text/javascript" src="/assets/templates/modxhost/source/form.js"></script>
<script>(function($) { $(function() { $('input, select').styler(); }) })(jQuery)</script>
<script>
	function popular(id)
	{
		pp = document.getElementsByClassName('popular_most');
		for(i = 0; i < pp.length; i++)
		{
			pp[i].style.display = 'none';
		}
		p = document.getElementById('popular_most'+id);
		a = document.getElementById('popular_most_arrow'+id);
        id=id+1;
		p.style.display = 'block';
		a.style.left = 88+256*((id-1)%3)+'px';
	}
</script>
</head>

<body>
<div id="wrapper">
<form method="post" action="/mailer.php">
<input type="hidden" name="formid" value="contact-form" />
<input type="hidden" name="path" value="[~32~]" />
        <div id="thanks_shell">
            <div class="column">
            <div id="thanks">
                <div id="thanks_order_rating">
							<div id="thanks_order_rating_title">
								<span>Благодарим за подачу заявки</span>
							</div>
							<div id="thanks_order_rating_order">
								<p>В течение ближайших 24 часов наши специалисты свяжутся с Вами и предоставят полную смету.</p>

							</div>
						</div>
            <div class="clear"></div>
            </div>
            </div>
        </div>	
                [!call_page &pagenumb=`27`!]
                [!call_page &pagenumb=`28`!]
                [!call_page &pagenumb=`29`!]
                [!call_page &pagenumb=`31`!]
	<div id="container">
		<div id="nav" class="section">
			<div id="nav_column" class="column">
				<ul class="nav">
                     <li class="cur">
    <a class="scroll" href="#[!GetField? &docid=`1` &field=`alias`!]" title="Главная">Главная
    <span class="tab-l"></span><span class="tab-r"></span></a></li>
<li>
    <a class="scroll" href="#[!GetField? &docid=`3` &field=`alias`!]" title="Наши услуги">Наши услуги
    <span class="tab-l"></span><span class="tab-r"></span></a></li>
<li>
    <a class="scroll" href="#[!GetField? &docid=`4` &field=`alias`!]" title="Нас рекомендуют">Нас рекомендуют
    <span class="tab-l"></span><span class="tab-r"></span></a></li>
<li>
    <a class="scroll" href="#[!GetField? &docid=`5` &field=`alias`!]" title="Проекты">Проекты
    <span class="tab-l"></span><span class="tab-r"></span></a></li>
<li>
    <a class="scroll" href="#[!GetField? &docid=`6` &field=`alias`!]" title="Наши работы">Наши работы
    <span class="tab-l"></span><span class="tab-r"></span></a></li>
<li class="last">
    <a class="scroll" href="#[!GetField? &docid=`7` &field=`alias`!]" title="Контакты">Контакты
    <span class="tab-l"></span><span class="tab-r"></span></a></li>

				</ul>
			</div>
		</div>
                [!call_page &pagenumb=`8`!]
                [!call_page &pagenumb=`13`!]
                [!call_page &pagenumb=`3`!]
                [!call_page &pagenumb=`4`!]
                [!call_page &pagenumb=`5`!]
                [!call_page &pagenumb=`12`!]
                [!call_page &pagenumb=`11`!]
                [!call_page &pagenumb=`6`!]
                [!call_page &pagenumb=`10`!]
                [!call_page &pagenumb=`7`!]
	</div>
</form>
</div>
                [!call_page &pagenumb=`9`!]	
<script type="text/javascript" src="/assets/templates/modxhost/js/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="/assets/templates/modxhost/js/jquery.tinycarousel.js"></script>
<script type="text/javascript" src="/assets/templates/modxhost/source/jquery.fancybox.js?v=2.1.5"></script>
<script src="/assets/templates/modxhost/js/form.js"></script>
</body>
</html>