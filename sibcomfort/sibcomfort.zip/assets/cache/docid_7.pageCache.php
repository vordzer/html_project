<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:1:"7";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:16:"Контакты";s:9:"longtitle";s:25:"КАК НАС НАЙТИ?";s:11:"description";s:0:"";s:5:"alias";s:8:"contacts";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:340:"<div id="map_address_city"><span>г.Красноярск, Северное шоссе 7/1</span></div>
<div id="map_address_call"><span>Звоните! С 9:00 до 21:00</span></div>
<div id="map_address_number"><span>+7 (800) 654-33-12</span></div>
<div id="map_address_letter"><span>Пишите! В любое время</span></div>";s:8:"richtext";s:1:"1";s:8:"template";s:2:"14";s:9:"menuindex";s:1:"5";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407524521";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407569548";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407524521";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="map" class="section">
            <a id="contacts" class="anchor"></a>
			<div id="map_t" class="section">
				<div id="map_title">
					<h2>КАК НАС НАЙТИ?</h2>
				</div>
				<div id="map_body">
					<div id="map_column" class="column">
						<div id="map_address">
						<div id="map_address_city"><span>г.Красноярск, Северное шоссе 7/1</span></div>
<div id="map_address_call"><span>Звоните! С 9:00 до 21:00</span></div>
<div id="map_address_number"><span>+7 (800) 654-33-12</span></div>
<div id="map_address_letter"><span>Пишите! В любое время</span></div>
							<div id="map_address_order_call">
								<a href="#" id="map_order_call" class="button button_tall popup_call">Обратный звонок</a>
							</div>
						</div>
					</div>
					<div id="map_full">
						<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2226.2975911929334!2d92.94185900000001!3d56.082767!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5cd7a8b24fe5cb41%3A0x873c9873dcd4af6!2z0YguINCh0LXQstC10YDQvdC-0LUg0YguLCA3LzEsINCa0YDQsNGB0L3QvtGP0YDRgdC6LCDQmtGA0LDRgdC90L7Rj9GA0YHQutC40Lkg0LrRgNCw0Lk!5e0!3m2!1sru!2sru!4v1407262654372" width="100%" height="456" frameborder="0" style="border:0"></iframe>
					</div>
				</div>
			</div>
		</div>