<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:2:"11";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:5:"ideal";s:9:"longtitle";s:0:"";s:11:"description";s:0:"";s:5:"alias";s:0:"";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:0:"";s:8:"richtext";s:1:"1";s:8:"template";s:2:"11";s:9:"menuindex";s:1:"9";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407562099";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407562099";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407562099";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"1";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="selection" class="section">
			<div id="selection_b" class="section">
				<div id="selection_column" class="column">
					<div id="selection_title">
						<h2></h2>
					</div>
					<div id="selection_form">
						<div id="selection_options">
							<div id="selection_options_group1" class="selection_options_group">
								<div id="selectio_group_title1" class="selectio_group_title">
									<span>ТИП ПРОЕКТА</span>
								</div>
								<div id="selection_group_items1" class="selection_group_items">
									<div id="selection_item1" class="selection_item">
										<input id="type1" checked form="contact-form" type="radio" name="type" value=Дом><label for="type1">Дом</label>
									</div>
									<div id="selection_item2" class="selection_item">
										<input id="type2" form="contact-form" type="radio" name="type" value=Баня><label for="type2">Баня</label>
									</div>
									<div id="selection_item3" class="selection_item">
										<input id="type3" form="contact-form" type="radio" name="type" value=Бытовка><label for="type3">Бытовка</label>
									</div>
									<div id="selection_item4" class="selection_item">
										<input id="type4" form="contact-form" type="radio" name="type" value=Беседка><label for="type4">Беседка</label>
									</div>
								</div>
							</div>
							<div id="selection_options_group2" class="selection_options_group">
								<div id="selectio_group_title2" class="selectio_group_title">
									<span>ВИД БРУСА</span>
								</div>
								<div id="selection_group_items2" class="selection_group_items">
									<div id="selection_item5" class="selection_item">
										<input id="material1" form="contact-form" type="radio" name="material" value=Оциллиндрованный><label for="material1">Оциллиндрованный</label>
									</div>
									<div id="selection_item6" class="selection_item">
										<input checked id="material2" form="contact-form" type="radio" name="material" value=Профилированный><label for="material2">Профилированный</label>
									</div>
									<div id="selection_item7" class="selection_item">
										<input id="material3" form="contact-form" type="radio" name="material" value=Клееный><label for="material3">Клееный</label>
									</div>
									<div id="selection_item8" class="selection_item">
										<input id="material4" form="contact-form" type="radio" name="material" value=Не определился><label for="material4">Не определился</label>
									</div>
								</div>
							</div>
							<div id="selection_options_group3" class="selection_options_group">
								<div id="selectio_group_title3" class="selectio_group_title">
									<span>ХАРАКТЕРИСТИКА</span>
								</div>
								<div id="selection_group_items3" class="selection_group_items">
									<div id="selection_item9" class="selection_item">
										<label for="max_cost">Цена до</label><input name="max_cost" id="max_cost" type="text" class="selection_input selection_input_long">
									</div>
									<div id="selection_item10" class="selection_item">
										<label for="min_area">Площадь от</label><input id="min_area" type="text" class="selection_input" name="min_area"><label for="max_area">до</label><input id="max_area" name="max_area" type="text" class="selection_input">
									</div>
									<div id="selection_item11" class="selection_item">
										<label for="floors">Количество этажей</label><select id="floors" name="floors"><option value=1>1</option><option value=2>2</option><option value=3>3</option></select>
									</div>
									<div id="selection_item12" class="selection_item">
										<label for="extension">Нужна пристройка?</label><select id="extension" name="extension"><option value=Нет>Нет</option><option value=да>Да</option></select>
									</div>
								</div>
							</div>
						</div>
						<div id="selection_submit">
							<a href="3" class="button button_selection popup_raschet">Подобрать проект</a>
						</div>
					</div>
				</div>
			</div>
		</div>