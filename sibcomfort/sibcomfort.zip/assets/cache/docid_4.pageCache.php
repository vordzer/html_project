<?php die('Unauthorized access.'); ?>a:44:{s:2:"id";s:1:"4";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:29:"Нас рекомендуют";s:9:"longtitle";s:67:"ПОЧЕМУ НАШИ КЛИЕНТЫ РЕКОМЕНДУЮТ НАС?";s:11:"description";s:0:"";s:5:"alias";s:13:"our_recommend";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:0:"";s:8:"richtext";s:1:"1";s:8:"template";s:1:"8";s:9:"menuindex";s:1:"2";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407524458";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407570985";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407524467";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:4:"com1";a:5:{i:0;s:4:"com1";i:1;s:103:"Сдаем проект всегда в срок (вернем деньги за срыв сроков)";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com2";a:5:{i:0;s:4:"com2";i:1;s:74:"Работают только русские опытные мастера";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com3";a:5:{i:0;s:4:"com3";i:1;s:49:"Оставляем за собой порядок";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com4";a:5:{i:0;s:4:"com4";i:1;s:101:"Никаких дополнительных расходов (прописано в договоре)";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com5";a:5:{i:0;s:4:"com5";i:1;s:83:"Даем гарантию на дом (подтверждено договором)";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com6";a:5:{i:0;s:4:"com6";i:1;s:106:"Только качественные материалы, проходят жесткий контроль";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="advantages" class="section">
            <a id="our_recommend" class="anchor"></a>
			<div id="advantages_column" class="column">
				<div id="advantages_title">
					<h2>ПОЧЕМУ НАШИ КЛИЕНТЫ РЕКОМЕНДУЮТ НАС?</h2>
				</div>
				<div id="advantages_items">
					<div id="advantage1" class="advantage advantage_l">
						<div id="advantage_number1" class="advantage_number">
							<span>1</span>
						</div>
						<div id="advantage_title1" class="advantage_title">
							<p>Сдаем проект всегда в срок (вернем деньги за срыв сроков)</p>
						</div>
					</div>
					<div id="advantage2" class="advantage advantage_l">
						<div id="advantage_number2" class="advantage_number">
							<span>2</span>
						</div>
						<div id="advantage_title2" class="advantage_title">
							<p>Работают только русские опытные мастера</p>
						</div>
					</div>
					<div id="advantage3" class="advantage advantage_l">
						<div id="advantage_number3" class="advantage_number">
							<span>3</span>
						</div>
						<div id="advantage_title3" class="advantage_title">
							<p>Оставляем за собой порядок</p>
						</div>
					</div>
					<div id="advantage4" class="advantage advantage_r">
						<div id="advantage_number4" class="advantage_number">
							<span>4</span>
						</div>
						<div id="advantage_title4" class="advantage_title">
							<p>Никаких дополнительных расходов (прописано в договоре)</p>
						</div>
					</div>
					<div id="advantage5" class="advantage advantage_r">
						<div id="advantage_number5" class="advantage_number">
							<span>5</span>
						</div>
						<div id="advantage_title5" class="advantage_title">
							<p>Даем гарантию на дом (подтверждено договором)</p>
						</div>
					</div>
					<div id="advantage6" class="advantage advantage_r">
						<div id="advantage_number6" class="advantage_number">
							<span>6</span>
						</div>
						<div id="advantage_title6" class="advantage_title">
							<p>Только качественные материалы, проходят жесткий контроль</p>
						</div>
					</div>
				</div>
			</div>
		</div>