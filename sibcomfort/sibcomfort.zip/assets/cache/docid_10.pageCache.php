<?php die('Unauthorized access.'); ?>a:42:{s:2:"id";s:2:"10";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:7:"calling";s:9:"longtitle";s:50:"Обратитесь в нашу компанию!";s:11:"description";s:0:"";s:5:"alias";s:0:"";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:0:"";s:8:"richtext";s:1:"1";s:8:"template";s:2:"13";s:9:"menuindex";s:1:"8";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407562079";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407570220";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407562079";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"1";s:4:"com1";a:5:{i:0;s:4:"com1";i:1;s:84:"Хотите, чтобы Ваш дом строила опытная бригада?";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com2";a:5:{i:0;s:4:"com2";i:1;s:66:"Хотите, чтобы проект был сдан в срок?";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com3";a:5:{i:0;s:4:"com3";i:1;s:83:"Хотите, чтобы строительство не было кошмаром?";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com4";a:5:{i:0;s:4:"com4";i:1;s:88:"Хотите получить дом из качественных материалов?";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="order" class="section">
			<div id="order_t" class="section">
				<div id="order_b" class="section">
					<div id="order_strip1" class="order_strip"><div class="order_strip_body"></div></div>
					<div id="order_strip2" class="order_strip"><div class="order_strip_body"></div></div>
					<div id="order_strip3" class="order_strip"><div class="order_strip_body"></div></div>
					<div id="order_strip4" class="order_strip"><div class="order_strip_body"></div></div>
					<div id="order_column" class="column">
						<div id="order_wants">
							<div id="want1" class="want"><span>Хотите, чтобы Ваш дом строила опытная бригада?</span></div>
							<div id="want2" class="want"><span>Хотите, чтобы проект был сдан в срок?</span></div>
							<div id="want3" class="want"><span>Хотите, чтобы строительство не было кошмаром?</span></div>
							<div id="want4" class="want"><span>Хотите получить дом из качественных материалов?</span></div>
							<div id="order_do"><span>Обратитесь в нашу компанию!</span></div>
						</div>
						<div id="order_rating">
							<div id="order_rating_title">
								<span>Заявка на расчет</span>
							</div>
							<div id="order_rating_order">
								<p>Оставьте заявку на бесплатный расчет проекта <span class="rating_now">сейчас</span> и Вы получите точную смету в течении 24 часов</p>
									<input type="text" name="name_call" class="rating_input" placeholder="Введите ваше имя">
									<input type="text" name="phone_calli" class="rating_input" placeholder="Введите номер телефона">
									<input type="submit" class="rating_submit" id="c_submit" value="Отправить заявку">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>