<?php die('Unauthorized access.'); ?>a:41:{s:2:"id";s:2:"13";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:4:"main";s:9:"longtitle";s:107:"СТРОИТЕЛЬСТВО ДОМОВ ИЗ БРУСА И БРЕВНА В КРАСНОЯРСКОМ КРАЕ!";s:11:"description";s:0:"";s:5:"alias";s:0:"";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:97:"<span class="main_action">Акция!</span> Установка 3-х окон бесплатно!";s:8:"richtext";s:1:"1";s:8:"template";s:1:"6";s:9:"menuindex";s:2:"11";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407564560";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407570840";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407564560";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"1";s:4:"com1";a:5:{i:0;s:4:"com1";i:1;s:80:"<span class="main_stat_digit">118</span> построенных объектов";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com2";a:5:{i:0;s:4:"com2";i:1;s:78:"<span class="main_stat_digit">4248</span> кв.м. нами застроено";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:4:"com3";a:5:{i:0;s:4:"com3";i:1;s:58:"<span class="main_stat_digit">5</span> лет работы";i:2;s:0:"";i:3;s:0:"";i:4;s:4:"text";}s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="main" class="section">
			<div id="main_b" class="section">
				<div id="main_strip1" class="main_strip"></div>
				<div id="main_strip2" class="main_strip"></div>
				<div id="main_strip3" class="main_strip"></div>
				<div id="main_column" class="column">
					<div id="main_top" class="column">
						<div id="main_title">
							<h1>СТРОИТЕЛЬСТВО ДОМОВ ИЗ БРУСА И БРЕВНА В КРАСНОЯРСКОМ КРАЕ!</h1>
						</div>
						<div id="main_action">
							<p><span class="main_action">Акция!</span> Установка 3-х окон бесплатно!</p>
						</div>
					</div>
					<div id="main_bottom">
						<div id="main_stat">
							<div id="main_stat_count" class="main_stat">
								<p><span class="main_stat_digit">118</span> построенных объектов</p>
							</div>
							<div id="main_stat_area" class="main_stat">
								<p><span class="main_stat_digit">4248</span> кв.м. нами застроено</p>
							</div>
							<div id="main_stat_years" class="main_stat">
								<p><span class="main_stat_digit">5</span> лет работы</p>
							</div>
						</div>
						<div id="main_rating">
							<div id="main_rating_title">
								<span>Заявка на расчет</span>
							</div>
							<div id="main_rating_order">
								<p>Оставьте заявку на бесплатный расчет проекта <span class="rating_now">сейчас</span> и Вы получите точную смету в течении 24 часов</p>
									<input type="text" name="name_top" class="rating_input" placeholder="Введите ваше имя">
									<input type="text" name="phone_top" class="rating_input" placeholder="Введите номер телефона">
									<input type="submit" id="m_submit" class="rating_submit" value="Отправить заявку">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>