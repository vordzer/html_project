<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:1:"3";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:21:"Наши услуги";s:9:"longtitle";s:98:"СИБ-КОМФОРТ УЖЕ БОЛЕЕ 5 ЛЕТ ЗАНИМАЕТСЯ СТРОИТЕЛЬСТВОМ";s:11:"description";s:0:"";s:5:"alias";s:10:"our_uslugi";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"1";s:9:"introtext";s:0:"";s:7:"content";s:401:"<h3>Install Successful!</h3>
<p>You have successfully installed MODX.</p>
<h3>Getting Help</h3>
<p>The <a href="http://forums.modx.com/" target="_blank">MODX Community</a> provides a great starting point to learn all things MODX, or you can also <a href="http://modxcms.com/learn/it.html">see some great learning resources</a> (books, tutorials, blogs and screencasts).</p>
<p>Welcome to MODX!</p>";s:8:"richtext";s:1:"1";s:8:"template";s:1:"7";s:9:"menuindex";s:1:"0";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1407524410";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1407571729";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1407524437";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:21:"Наши услуги";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->		<div id="products" class="section">
            <a id="our_uslugi" class="anchor"></a>
			<div id="products_b" class="section">
				<div id="products_column" class="column">
					<div id="products_title">
						<h2>СИБ-КОМФОРТ УЖЕ БОЛЕЕ 5 ЛЕТ ЗАНИМАЕТСЯ СТРОИТЕЛЬСТВОМ</h2>
					</div>
					<div id="products_items">

            [!Ditto?&tpl=`usl`&id=`w1`&display=`5`&paginate=`0`&orderBy=`ASC`!]
					</div>
				</div>
			</div>
		</div>