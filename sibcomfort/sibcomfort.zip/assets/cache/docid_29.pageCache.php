<?php die('Unauthorized access.'); ?>a:38:{s:2:"id";s:2:"29";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:30:"Заявка на расчет";s:9:"longtitle";s:7:"raschet";s:11:"description";s:0:"";s:5:"alias";s:0:"";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:0:"";s:7:"content";s:216:"<p>Оставьте заявку на бесплатный расчет проекта <span class="rating_now">сейчас</span> и Вы получите точную смету в течении 24 часов</p>";s:8:"richtext";s:1:"1";s:8:"template";s:2:"19";s:9:"menuindex";s:2:"14";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1408035090";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1408035602";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:10:"1408035166";s:11:"publishedby";s:1:"1";s:9:"menutitle";s:0:"";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"1";s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__-->        <div id="pop_up_shell_raschet" class="pop_up_shell">
            <div class="column">
            <div id="pop_up_raschet" class="pop_up">
                <div class="p_order_rating">
							<div class="p_order_rating_title">
								<span>Заявка на расчет</span>
							</div>
							<div class="p_order_rating_order">
<p>Оставьте заявку на бесплатный расчет проекта <span class="rating_now">сейчас</span> и Вы получите точную смету в течении 24 часов</p>
									<input type="text" name="phone_raschet" class="rating_input" placeholder="Введите номер телефона">
									<input type="submit" id="p_submit_raschet" class="rating_submit" value="Отправить заявку">
							</div>
						</div>
            <div class="clear"></div>
            </div>
            </div>
        </div>